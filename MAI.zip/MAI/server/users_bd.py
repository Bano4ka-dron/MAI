import sqlite3
from contextlib import closing
import os
import uuid

DB_NAME = 'users_database.db'  # Одно имя для всей БД

def add_user(name, regmail, pass_hash, gender, date):
    """Добавить пользователя"""
    with closing(sqlite3.connect(DB_NAME)) as conn:
        cursor = conn.cursor()
        try:
            cursor.execute(
                "INSERT INTO users (name, password, email, gender, date) VALUES (?, ?, ?, ?, ?)",
                (name, pass_hash, regmail, gender, date)
            )
            conn.commit()
            return True
        except sqlite3.IntegrityError:
            # Email уже существует (UNIQUE constraint)
            return False

def get_user(email):
    """Получить пользователя по email"""
    with closing(sqlite3.connect(DB_NAME)) as conn:
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute(
            "SELECT id, name, password, email FROM users WHERE email = ?",
            (email,)
        )
        user = cursor.fetchone()
        
        if user:
            return dict(user)
        return None

def get_product():
    conn=sqlite3.connect('users_database.db')
    cursor=conn.cursor()
    cursor.execute("SELECT * FROM catalog")

    rows=cursor.fetchall()

    product=[]

    for row in rows:
        product.append({
            'id':row[0],
            'type':row[1],
            'name':row[2],
            'price':row[3],
            'image':row[4]
        })

    conn.close()
    return product

def add_product(name, type, price, image):
    try:
        conn=sqlite3.connect('users_database.db')
        cursor=conn.cursor()

        cursor.execute("""
        INSERT INTO catalog (name, type, price, image)
        VALUES (?,?,?,?)
""", (type, name, price, image))
        conn.commit()
        conn.close()
        return True

    except:
        print(f"Ошибка добавления товара")
        return False

def delete_product(product_id):
    """Удалить товар по ID"""
    try:
        with closing(sqlite3.connect(DB_NAME)) as conn:
            cursor = conn.cursor()
            # Сначала получаем путь к картинке, чтобы удалить файл
            cursor.execute("SELECT image FROM catalog WHERE id = ?", (product_id,))
            row = cursor.fetchone()
            
            if row:
                # Удаляем запись из БД
                cursor.execute("DELETE FROM catalog WHERE id = ?", (product_id,))
                # Удаляем связанные записи из избранного
                # cursor.execute("DELETE FROM user_favorites WHERE product_id = ?", (product_id,))
                conn.commit()
                
                # Пытаемся удалить файл картинки
                image_path = row[0]
                if image_path:
                    # image_path хранится как "../images/uuid.jpg", нужно превратить в "images/uuid.jpg"
                    real_path = image_path.replace('../', '')
                    if os.path.exists(real_path):
                        os.remove(real_path)
                        print(f"Удален файл: {real_path}")
                
                return True
            return False
    except Exception as e:
        print(f"Ошибка удаления товара: {e}")
        return False

def get_all_products():
    """Получить все товары (для админки)"""
    with closing(sqlite3.connect(DB_NAME)) as conn:
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute("SELECT id, type, name, price, image FROM catalog ORDER BY id DESC")
        return [dict(row) for row in cursor.fetchall()]


def toggle_favorite(user_id, product_id):
    """Добавляет товар в избранное, если его там нет, или удаляет, если есть"""
    try:
        with closing(sqlite3.connect(DB_NAME)) as conn:
            cursor = conn.cursor()
            
            # Проверяем, есть ли уже эта запись
            cursor.execute(
                "SELECT id FROM user_favorites WHERE user_id = ? AND product_id = ?", 
                (user_id, product_id)
            )
            exists = cursor.fetchone()
            
            if exists:
                # Если есть — удаляем
                cursor.execute(
                    "DELETE FROM user_favorites WHERE user_id = ? AND product_id = ?", 
                    (user_id, product_id)
                )
            else:
                # Если нет — добавляем
                cursor.execute(
                    "INSERT INTO user_favorites (user_id, product_id) VALUES (?, ?)", 
                    (user_id, product_id)
                )
                
            conn.commit()
            return True
            
    except Exception as e:
        print(f"Ошибка toggle_favorite: {e}")
        return False


def get_user_favorites(user_id):
    """Получает список товаров из избранного для конкретного пользователя"""
    try:
        with closing(sqlite3.connect(DB_NAME)) as conn:
            # Позволяет обращаться к колонкам по имени (c.name, c.price и т.д.)
            conn.row_factory = sqlite3.Row 
            cursor = conn.cursor()
            
            # Объединяем таблицу товаров (catalog) с таблицей избранного (user_favorites)
            cursor.execute("""
                SELECT c.id, c.type, c.name, c.price, c.image 
                FROM catalog c
                INNER JOIN user_favorites f ON c.id = f.product_id
                WHERE f.user_id = ?
                ORDER BY f.id DESC
            """, (user_id,))
            
            # Преобразуем результат в список словарей для JSON-ответа
            return [dict(row) for row in cursor.fetchall()]
            
    except Exception as e:
        print(f"Ошибка get_user_favorites: {e}")
        return []


# Создание таблицы при первом запуске
def init_db():
    """Создать таблицу, если её нет"""
    with closing(sqlite3.connect(DB_NAME)) as conn:
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                password TEXT NOT NULL,
                email TEXT UNIQUE,
                gender TEXT,
                date DATE
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS catalog (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            type TEXT NOT NULL,
            name TEXT NOT NULL,
            price INTEGER,
            image TEXT NOT NULL UNIQUE
            )
        ''')
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS user_favorites (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            product_id INTEGER NOT NULL,
            UNIQUE(user_id, product_id) ON CONFLICT REPLACE
        )
        ''')
    # conn.commit()

# Вызываем при импорте модуля
init_db()