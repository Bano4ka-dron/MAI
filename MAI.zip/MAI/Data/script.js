document.addEventListener('DOMContentLoaded', () => {
    const height = document.getElementById('data-height');
    const weight = document.getElementById('data-weight');
    const shoe = document.getElementById('data-shoe');
    const clothes = document.getElementById('data-clothes');
    const age = document.getElementById('data-age');
    const chest = document.getElementById('data-chest');
    const waist = document.getElementById('data-waist');

    const errHeight = document.getElementById('err-height');
    const errWeight = document.getElementById('err-weight');
    const errShoe = document.getElementById('err-shoe');
    const errClothes = document.getElementById('err-clothes');
    const errAge = document.getElementById('err-age');
    const errChest = document.getElementById('err-chest');
    const errWaist = document.getElementById('err-waist');

    const nextBtn = document.getElementById('data-next');

    function showError(input, errEl, message) {
        input.classList.add('data-field--invalid');
        errEl.textContent = message;
        errEl.classList.add('is-visible');
    }

    function clearError(input, errEl) {
        input.classList.remove('data-field--invalid');
        errEl.textContent = '';
        errEl.classList.remove('is-visible');
    }

    function digitsOnly(input) {
        input.addEventListener('input', () => {
            input.value = input.value.replace(/\D/g, '');
        });
    }

    digitsOnly(age);

    function validateHeight() {
        const v = parseInt(height.value, 10);
        if (!height.value) {
            showError(height, errHeight, 'Введите рост');
            return false;
        }
        if (isNaN(v) || v < 30 || v > 300) {
            showError(height, errHeight, 'Рост от 30 до 300 см');
            return false;
        }
        clearError(height, errHeight);
        return true;
    }

    function validateWeight() {
        const v = parseInt(weight.value, 10);
        if (!weight.value) {
            showError(weight, errWeight, 'Введите вес');
            return false;
        }
        if (isNaN(v) || v < 2 || v > 700) {
            showError(weight, errWeight, 'Вес от 2 до 700 кг');
            return false;
        }
        clearError(weight, errWeight);
        return true;
    }

    function validateShoe() {
        const v = parseInt(shoe.value, 10);
        if (!shoe.value) {
            showError(shoe, errShoe, 'Введите размер обуви');
            return false;
        }
        if (isNaN(v) || v < 30 || v > 60) {
            showError(shoe, errShoe, 'Размер обуви от 30 до 60');
            return false;
        }
        clearError(shoe, errShoe);
        return true;
    }

    function validateClothes() {
        if (!clothes.value) {
            showError(clothes, errClothes, 'Выберите размер одежды');
            return false;
        }
        clearError(clothes, errClothes);
        return true;
    }

    function validateAge() {
        if (!age.value.trim()) {
            clearError(age, errAge);
            return true;
        }
        const v = parseInt(age.value, 10);
        if (isNaN(v) || v < 1 || v > 150) {
            showError(age, errAge, 'Возраст от 1 до 150');
            return false;
        }
        clearError(age, errAge);
        return true;
    }

    function validateChest() {
        if (!chest.value.trim()) {
            clearError(chest, errChest);
            return true;
        }
        const v = parseInt(chest.value, 10);
        if (isNaN(v) || v < 30 || v > 200) {
            showError(chest, errChest, 'Обхват груди от 30 до 200 см');
            return false;
        }
        clearError(chest, errChest);
        return true;
    }

    function validateWaist() {
        if (!waist.value.trim()) {
            clearError(waist, errWaist);
            return true;
        }
        const v = parseInt(waist.value, 10);
        if (isNaN(v) || v < 30 || v > 302) {
            showError(waist, errWaist, 'Обхват талии от 30 до 302 см');
            return false;
        }
        clearError(waist, errWaist);
        return true;
    }

    function attachSuffix(input, suffix, errEl) {
        const SUFFIX_FULL = ' ' + suffix;

        function apply() {
            const raw = input.value;

            const digits = raw.replace(/\D/g, '');

            if (!digits) {
                input.value = '';
                return;
            }

            const next = digits + SUFFIX_FULL;

            if (raw !== next) {
                input.value = next;
            }

            const pos = digits.length;
            input.setSelectionRange(pos, pos);
        }

        input.addEventListener('input', () => {
            apply();
            clearError(input, errEl);
        });

        input.addEventListener('focus', () => {
            const digits = input.value.replace(/\D/g, '');
            if (digits) {
                input.value = digits + SUFFIX_FULL;
                const pos = digits.length;
                input.setSelectionRange(pos, pos);
            }
        });

        input.addEventListener('keydown', (e) => {
            if (e.key === 'ArrowRight' || e.key === 'End') {
                const digits = input.value.replace(/\D/g, '');
                e.preventDefault();
                const pos = digits.length;
                input.setSelectionRange(pos, pos);
            }
        });

        input.addEventListener('blur', () => {
            apply();
            validateByInput(input);
        });
    }

    function validateByInput(input) {
        if (input === height) validateHeight();
        else if (input === weight) validateWeight();
        else if (input === shoe) validateShoe();
        else if (input === age) validateAge();
        else if (input === chest) validateChest();
        else if (input === waist) validateWaist();
    }

    attachSuffix(height, 'см', errHeight);
    attachSuffix(weight, 'кг', errWeight);
    attachSuffix(shoe, 'MP', errShoe);
    attachSuffix(chest, 'см', errChest);
    attachSuffix(waist, 'см', errWaist);

    age.addEventListener('blur', validateAge);
    age.addEventListener('input', () => clearError(age, errAge));

    clothes.addEventListener('change', () => {
        clearError(clothes, errClothes);
        validateClothes();
    });

    if (nextBtn) {
        nextBtn.addEventListener('click', (e) => {
            const requiredOk =
                validateHeight() &
                validateWeight() &
                validateShoe() &
                validateClothes();

            validateAge();
            validateChest();
            validateWaist();

            if (!requiredOk) {
                e.preventDefault();
                return;
            }

            console.log('Данные валидны', {
                height: height.value,
                weight: weight.value,
                shoe: shoe.value,
                clothes: clothes.value,
                age: age.value,
                chest: chest.value,
                waist: waist.value,
                notes: document.getElementById('data-notes').value
            });
        });
    }
});