document.addEventListener('DOMContentLoaded', () => {
    const scroll = document.getElementById('fitting-scroll');
    const thumb = document.getElementById('fitting-thumb');

    if (scroll && thumb) {
        const track = thumb.parentElement;

        function updateThumb() {
            const maxScroll = scroll.scrollHeight - scroll.clientHeight;
            if (maxScroll <= 0) {
                thumb.style.height = track.clientHeight + 'px';
                thumb.style.top = '0px';
                return;
            }
            const ratio = scroll.clientHeight / scroll.scrollHeight;
            const h = Math.max(60, track.clientHeight * ratio);
            thumb.style.height = h + 'px';
            const progress = scroll.scrollTop / maxScroll;
            const maxTop = track.clientHeight - h;
            thumb.style.top = (progress * maxTop) + 'px';
        }

        scroll.addEventListener('scroll', updateThumb);
        window.addEventListener('resize', updateThumb);

        let isDragging = false;
        let startY = 0;
        let startTop = 0;

        thumb.addEventListener('mousedown', (e) => {
            isDragging = true;
            startY = e.clientY;
            startTop = thumb.offsetTop;
            thumb.style.cursor = 'grabbing';
            e.preventDefault();
        });

        document.addEventListener('mousemove', (e) => {
            if (!isDragging) return;
            const deltaY = e.clientY - startY;
            const maxTop = track.clientHeight - thumb.offsetHeight;
            let newTop = startTop + deltaY;
            newTop = Math.max(0, Math.min(newTop, maxTop));
            thumb.style.top = newTop + 'px';
            const ratio = maxTop === 0 ? 0 : newTop / maxTop;
            scroll.scrollTop = ratio * (scroll.scrollHeight - scroll.clientHeight);
        });

        document.addEventListener('mouseup', () => {
            if (!isDragging) return;
            isDragging = false;
            thumb.style.cursor = 'grab';
        });

        track.addEventListener('click', (e) => {
            if (e.target === thumb) return;
            const rect = track.getBoundingClientRect();
            const clickY = e.clientY - rect.top - thumb.offsetHeight / 2;
            const maxTop = track.clientHeight - thumb.offsetHeight;
            const ratio = Math.max(0, Math.min(clickY / maxTop, 1));
            scroll.scrollTop = ratio * (scroll.scrollHeight - scroll.clientHeight);
        });

        updateThumb();
    }

    const btn = document.getElementById('fitting-btn');
    const saved = document.getElementById('fitting-saved');
    const status = document.getElementById('fitting-status');
    const loader = document.getElementById('fitting-loader');
    const message = document.getElementById('fitting-message');
    const iconLeft = document.getElementById('fitting-icon-left');
    const iconRight = document.getElementById('fitting-icon-right');
    if (!btn || !saved || !status || !loader || !message || !iconLeft || !iconRight) return;

    let state = 'idle';

    function hideSaved() {
        saved.disabled = true;
        saved.style.opacity = '0';
        saved.style.pointerEvents = 'none';
    }

    function showSaved() {
        saved.disabled = false;
        saved.style.opacity = '1';
        saved.style.pointerEvents = 'auto';
    }

    btn.addEventListener('click', () => {
        if (state === 'idle') {
            state = 'loading';
            status.classList.add('is-visible');
            loader.classList.add('is-visible');
            message.classList.remove('is-visible');
            iconLeft.classList.remove('is-visible');
            iconRight.classList.remove('is-visible');
            btn.textContent = 'Примерить';
            btn.disabled = true;
            btn.style.opacity = '0';
            hideSaved();

            setTimeout(() => {
                state = 'done';
                loader.classList.remove('is-visible');
                message.classList.add('is-visible');
                iconLeft.classList.add('is-visible');
                iconRight.classList.add('is-visible');
                btn.textContent = 'Назад';
                btn.disabled = false;
                btn.style.opacity = '1';
                showSaved();
            }, 10000);
        } else if (state === 'done') {
            state = 'idle';
            status.classList.remove('is-visible');
            loader.classList.remove('is-visible');
            message.classList.remove('is-visible');
            iconLeft.classList.remove('is-visible');
            iconRight.classList.remove('is-visible');
            btn.textContent = 'Примерить';
            showSaved();
        }
    });
});