document.addEventListener('DOMContentLoaded', () => {
    const block = document.getElementById('upload-block');
    const toggle = document.getElementById('upload-toggle');
    const input = document.getElementById('upload-input');
    if (!block || !toggle || !input) return;

    let isOpen = false;
    let activeFrame = null;

    toggle.addEventListener('click', () => {
        isOpen = !isOpen;
        block.classList.toggle('is-open', isOpen);
        toggle.innerHTML = isOpen ? 'Скрыть' : 'Доп.<br>фото';
    });

    document.querySelectorAll('.upload-frame').forEach(frame => {
        const icon = frame.querySelector('.upload-frame__icon');
        if (!icon) return;

        icon.addEventListener('click', (e) => {
            e.stopPropagation();
            activeFrame = frame;
            input.value = '';
            input.click();
        });
    });

    input.addEventListener('change', () => {
        if (!activeFrame) return;
        const file = input.files && input.files[0];
        if (!file) return;

        const url = URL.createObjectURL(file);

        let preview = activeFrame.querySelector('.upload-frame__preview');
        if (!preview) {
            preview = document.createElement('div');
            preview.className = 'upload-frame__preview';
            const img = document.createElement('img');
            img.alt = 'Загруженное фото';
            preview.appendChild(img);
            activeFrame.insertBefore(preview, activeFrame.firstChild);
        }

        const img = preview.querySelector('img');
        if (img) {
            const oldSrc = img.src;
            if (oldSrc && oldSrc.startsWith('blob:')) {
                URL.revokeObjectURL(oldSrc);
            }
            img.src = url;
        }

        activeFrame = null;
    });
});