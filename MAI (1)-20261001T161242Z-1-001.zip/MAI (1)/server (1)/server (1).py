from flask import Flask, request, jsonify
from flask_cors import CORS
import users_bd
from werkzeug.security import generate_password_hash, check_password_hash
import os
import uuid


app=Flask(__name__)
CORS(app)

UPLOAD_FOLDER='images'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'webp'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


@app.route('/api/save', methods=['POST'])
def save_data():
    data=request.get_json()

    name = data.get('name')
    regmail = data.get('email')
    regpass = data.get('password')
    pass_hash=generate_password_hash(regpass) #хеширование пароля
    gender=data.get('gender')
    date=data.get('date')


    success = users_bd.add_user(name,regmail,pass_hash,gender,date)

    if success:                 #возвращает ответ в консоль сайта
        return jsonify({"status": "ok", "message": "Регистрация успешна"})
    else:
        return jsonify({
            "status": "error", 
            "message": "Ошибка БД: возможно, пользователь с таким Email или Логином уже существует"
        }), 400


@app.route('/api/login', methods=['POST'])
def login_data():
    data=request.get_json()

    mail_log=data.get('mail') #введенные данные
    pass_log=data.get('pass')

    # print(mail_log, pass_log)

    if mail_log=='admin' and pass_log=='admin':
        #  print(123123)
         return jsonify({
              "status":"ok",
              "message":"Вход выполнен",
              "role":"admin"
         }), 200

    bd_data=users_bd.get_user(mail_log)#ищем в бд запись по почте

    if bd_data:
        correct=check_password_hash(bd_data['password'], pass_log)

        if correct:
                return jsonify({"status": "ok", "message": "Вход выполнен"}), 200
        else:
                return jsonify({"status": "error 1", "message": "Неверный пароль"}), 401
    else:
         return jsonify({"status": "error", "message": "Пользователь не найден"}), 404

@app.route('/api/products', methods=['GET'])
def products_data():
     products=users_bd.get_product()
     return jsonify(products)

@app.route('/api/admin/product', methods=['POST'])
def product_add():
    if 'image' not in request.files:
        return jsonify({"status": "error", "message": "Файл картинки не найден"}), 400
    
    file = request.files['image']

    if file.filename=='':
         return jsonify({"status": "error", "message": "Файл не выбран"}), 400

    if file and allowed_file(file.filename):
         ext=file.filename.rsplit('.',1)[1].lower()
         unique_filename=f"{uuid.uuid4().hex}.{ext}"

         filepath=os.path.join(UPLOAD_FOLDER, unique_filename)  

         file.save(filepath)
         
         type=request.form.get('type')
         name=request.form.get('name')
         price=request.form.get('price')     

         image=f"../images/{unique_filename}"

         success=users_bd.add_product(name,type,price,image)

         if success:
            return jsonify({"status": "ok", "message": "Товар успешно добавлен"}), 200
         else:
            return jsonify({"status": "error", "message": "Ошибка при добавлении в БД"}), 500
    else:
        return jsonify({"status": "error", "message": "Недопустимый формат. Разрешены: png, jpg, jpeg, webp"}), 400

@app.route('/api/admin/products', methods=['GET'])
def get_all_products():
    """Получить список всех товаров для админки"""
    products = users_bd.get_all_products()
    return jsonify(products)

@app.route('/api/admin/product/delete', methods=['POST'])
def delete_product():
    """Удалить товар по ID"""
    data = request.get_json()
    product_id = data.get('id')
    
    if not product_id:
        return jsonify({"status": "error", "message": "Не указан ID товара"}), 400
    
    success = users_bd.delete_product(product_id)
    
    if success:
        return jsonify({"status": "ok", "message": "Товар удален"}), 200
    else:
        return jsonify({"status": "error", "message": "Товар не найден или ошибка БД"}), 404



if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)